public class Familia {
    private Pessoa encarregadoEducacao = new Pessoa();
    private String parentescoEncEducacao;
    private Pessoa aluno = new Pessoa();
    
    public Familia() {
    }

    public Familia(Pessoa encarregadoEducacao, String parentescoEncEducacao, Pessoa aluno) {
        this.encarregadoEducacao = encarregadoEducacao;
        this.parentescoEncEducacao = parentescoEncEducacao;
        this.aluno = aluno;
    }

    public Pessoa getEncarregadoEducacao() {
        return encarregadoEducacao;
    }
    public void setEncarregadoEducacao(Pessoa encarregadoEducacao) {
        this.encarregadoEducacao = encarregadoEducacao;
    }
    public String getParentescoEncEducacao() {
        return parentescoEncEducacao;
    }
    public void setParentescoEncEducacao(String parentescoEncEducacao) {
        this.parentescoEncEducacao = parentescoEncEducacao;
    }
    public Pessoa getAluno() {
        return aluno;
    }
    public void setAluno(Pessoa aluno) {
        this.aluno = aluno;
    }

    @Override
    public String toString() {
        return "Familia [encarregadoEducacao=" + encarregadoEducacao + ", parentescoEncEducacao="
                + parentescoEncEducacao + ", aluno=" + aluno + "]";
    }

    public String getInfoEncEducacao() {
        return encarregadoEducacao + " - " + parentescoEncEducacao;
    }

    public String getInfoFamilia() {
        return "------ Encarregado de Educação ------" + "\n\nNome -> " +  encarregadoEducacao.getNomeCompleto() + "\nIdade -> " + encarregadoEducacao.calcularIdade() + 
        "\nNúmero CC ->" + encarregadoEducacao.getNumeroCC() + "\nParentesco -> " + parentescoEncEducacao + 
        "\n\n------ Aluno ------" + "\n\nNome -> " +  aluno.getNomeCompleto() + "\nIdade -> " + aluno.calcularIdade() + 
        "\nNúmero CC ->" + aluno.getNumeroCC();
    }
}
