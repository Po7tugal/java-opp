public class App {
    public static void main(String[] args) throws Exception {
        Pessoa p1 = new Pessoa();
        p1.setNumeroCC(14812);
        p1.setNomeProprio("Michael");
        p1.setNomeApelido("Jackson");
        p1.setMesNascimento(2);
        p1.setDiaNascimento(24);
        p1.setAnoNascimento(1960);

        Pessoa p2 = new Pessoa();
        p2.setNumeroCC(15913);
        p2.setNomeProprio("Michael");
        p2.setNomeApelido("Jordan");
        p2.setMesNascimento(5);
        p2.setDiaNascimento(30);
        p2.setAnoNascimento(1974);

        Familia family = new Familia();
        family.setAluno(p2);
        family.setEncarregadoEducacao(p1);
        family.setParentescoEncEducacao("Pai");

        System.out.print("******************* TESTE 1 *******************\n\n");

        System.out.print("------ PESSOA 1 ------\n\n");
        System.out.print("Nome -> ");
        System.out.println(p1.getNomeCompleto());
        System.out.print("Idade -> ");
        System.out.print(p1.calcularIdade());
        System.out.println(" Anos");
        System.out.print("Numero CC -> ");
        System.out.println(p1.getNumeroCC());

        System.out.print("\n------ PESSOA 2 ------\n\n");
        System.out.print("Nome -> ");
        System.out.println(p2.getNomeCompleto());
        System.out.print("Idade -> ");
        System.out.print(p2.calcularIdade());
        System.out.println(" Anos");
        System.out.print("Numero CC -> ");
        System.out.println(p2.getNumeroCC());

        System.out.print("\n");
        System.out.print(family.getInfoFamilia());
        System.out.print("\n");
    }
}
